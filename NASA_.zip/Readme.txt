// following libraries will be required can be installed using the following command uncomment the first cell
 pip install flask requests flask_ngrok ipython

// to run the code open the .ipynb file and click on run tab


// After successful run, navigate to http://127.0.0.1:5000/  You should see the real-time ISS coordinates being displayed on the map, and the polyline will show the ISS path, highlighting all previous coordinates.


